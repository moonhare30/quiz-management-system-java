package quiz.application;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javaapplication1.Login;

public class Score extends JFrame implements ActionListener {

    Score(String name, int score) {
        setBounds(400, 150, 1000, 600);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/quiz 2.jpg"));
        Image i2 = i1.getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(50, 100, 500, 250);
        add(image);

        JLabel heading = new JLabel("Thank you " + name + " please find your score below");
        heading.setBounds(45, 20, 700, 30);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(heading);

        JLabel lblscore = new JLabel("Your score is " + score);
        lblscore.setBounds(600, 150, 300, 35);
        lblscore.setFont(new Font("Calibri", Font.PLAIN, 26));
        add(lblscore);

        JButton submit = new JButton("Give Again");
        submit.setBounds(610, 230, 160, 40);
        submit.setBackground(new Color(30, 144, 255));
        submit.setFont(new Font("Claribri", Font.PLAIN, 18));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        add(submit);

        setSize(1000, 500);
        setLocation(400, 250);
        setVisible(true);
        
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Login();
    }

    public static void main(String[] args) {
        new Score("User", 0);
    }
}